
public class Question24
{
	public static void main(String args[])
	{
		int min=1;
		int max=100;
		System.out.println(Math.floor(Math.random()*(max-min+1))+1);
	}
}