import java.util.*;
public class Question15
{
	public static void main(String args[])
	{
		try
		{
			int x=2/0;
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}